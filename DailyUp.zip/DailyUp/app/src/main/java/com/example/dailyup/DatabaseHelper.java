package com.example.dailyup;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "DailyUp.db";
    private static final int DATABASE_VERSION = 1;

    // 북마크 테이블
    private static final String TABLE_BOOKMARKS = "bookmarks";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_QUOTE = "quote";
    private static final String COLUMN_TIMESTAMP = "timestamp";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_BOOKMARKS_TABLE = "CREATE TABLE " + TABLE_BOOKMARKS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_QUOTE + " TEXT NOT NULL,"
                + COLUMN_TIMESTAMP + " INTEGER DEFAULT (strftime('%s','now'))"
                + ")";
        db.execSQL(CREATE_BOOKMARKS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKMARKS);
        onCreate(db);
    }

    // 북마크 추가
    public long addBookmark(String quote) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_QUOTE, quote);

        long result = db.insert(TABLE_BOOKMARKS, null, values);
        db.close();
        return result;
    }

    // 모든 북마크 가져오기
    public List<String> getAllBookmarks() {
        List<String> bookmarks = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_BOOKMARKS + " ORDER BY " + COLUMN_TIMESTAMP + " DESC";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                String quote = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_QUOTE));
                bookmarks.add(quote);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return bookmarks;
    }

    // 북마크 삭제
    public void deleteBookmark(String quote) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_BOOKMARKS, COLUMN_QUOTE + " = ?", new String[]{quote});
        db.close();
    }

    // 북마크 존재 여부 확인
    public boolean isBookmarked(String quote) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_BOOKMARKS, null, COLUMN_QUOTE + " = ?",
                new String[]{quote}, null, null, null);

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }
}