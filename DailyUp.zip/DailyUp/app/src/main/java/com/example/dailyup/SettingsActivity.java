package com.example.dailyup;

import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private Switch switchNotification;
    private TextView tvNotificationTime;
    private Button btnSetTime;
    private Button btnResetSettings;

    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "DailyUpSettings";
    private static final String KEY_NOTIFICATION_ENABLED = "notification_enabled";
    private static final String KEY_NOTIFICATION_HOUR = "notification_hour";
    private static final String KEY_NOTIFICATION_MINUTE = "notification_minute";

    private int selectedHour = 9; // 기본값: 오전 9시
    private int selectedMinute = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        initializeViews();
        loadSettings();
        setupClickListeners();
    }

    private void initializeViews() {
        switchNotification = findViewById(R.id.switch_notification);
        tvNotificationTime = findViewById(R.id.tv_notification_time);
        btnSetTime = findViewById(R.id.btn_set_time);
        btnResetSettings = findViewById(R.id.btn_reset_settings);

        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
    }

    private void loadSettings() {
        boolean notificationEnabled = sharedPreferences.getBoolean(KEY_NOTIFICATION_ENABLED, true);
        selectedHour = sharedPreferences.getInt(KEY_NOTIFICATION_HOUR, 9);
        selectedMinute = sharedPreferences.getInt(KEY_NOTIFICATION_MINUTE, 0);

        switchNotification.setChecked(notificationEnabled);
        updateTimeDisplay();
        updateButtonState();
    }

    private void setupClickListeners() {
        switchNotification.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                saveNotificationEnabled(isChecked);
                updateButtonState();

                if (isChecked) {
                    NotificationHelper.scheduleDaily(SettingsActivity.this, selectedHour, selectedMinute);
                    Toast.makeText(SettingsActivity.this, "알림이 활성화되었습니다.", Toast.LENGTH_SHORT).show();
                } else {
                    NotificationHelper.cancelDaily(SettingsActivity.this);
                    Toast.makeText(SettingsActivity.this, "알림이 비활성화되었습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSetTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog();
            }
        });

        btnResetSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetSettings();
            }
        });
    }

    private void showTimePickerDialog() {
        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        selectedHour = hourOfDay;
                        selectedMinute = minute;
                        saveNotificationTime();
                        updateTimeDisplay();

                        if (switchNotification.isChecked()) {
                            NotificationHelper.scheduleDaily(SettingsActivity.this, selectedHour, selectedMinute);
                        }

                        Toast.makeText(SettingsActivity.this, "알림 시간이 설정되었습니다.", Toast.LENGTH_SHORT).show();
                    }
                }, selectedHour, selectedMinute, true);

        timePickerDialog.show();
    }

    private void updateTimeDisplay() {
        String timeText = String.format("%02d:%02d", selectedHour, selectedMinute);
        tvNotificationTime.setText("알림 시간: " + timeText);
    }

    private void updateButtonState() {
        btnSetTime.setEnabled(switchNotification.isChecked());
    }

    private void saveNotificationEnabled(boolean enabled) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(KEY_NOTIFICATION_ENABLED, enabled);
        editor.apply();
    }

    private void saveNotificationTime() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(KEY_NOTIFICATION_HOUR, selectedHour);
        editor.putInt(KEY_NOTIFICATION_MINUTE, selectedMinute);
        editor.apply();
    }

    private void resetSettings() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();

        // 기본값으로 재설정
        selectedHour = 9;
        selectedMinute = 0;
        switchNotification.setChecked(true);
        updateTimeDisplay();
        updateButtonState();

        // 알림 재설정
        NotificationHelper.scheduleDaily(this, selectedHour, selectedMinute);

        Toast.makeText(this, "설정이 초기화되었습니다.", Toast.LENGTH_SHORT).show();
    }
}