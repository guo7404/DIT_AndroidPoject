package com.example.dailyup;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CategoryActivity extends AppCompatActivity {

    private ListView lvCategories;
    private ListView lvQuotes;
    private TextView tvSelectedCategory;

    private Map<String, List<String>> categoryQuotes;
    private ArrayAdapter<String> categoryAdapter;
    private ArrayAdapter<String> quoteAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        initializeViews();
        initializeData();
        setupAdapters();
        setupClickListeners();
    }

    private void initializeViews() {
        lvCategories = findViewById(R.id.lv_categories);
        lvQuotes = findViewById(R.id.lv_quotes);
        tvSelectedCategory = findViewById(R.id.tv_selected_category);
    }

    private void initializeData() {
        categoryQuotes = new HashMap<>();

        // 자기계발
        List<String> selfDevelopment = new ArrayList<>();
        selfDevelopment.add("성공은 준비된 기회와 노력이 만나는 지점에서 일어난다.");
        selfDevelopment.add("오늘 할 수 있는 일을 내일로 미루지 말라.");
        selfDevelopment.add("작은 변화가 큰 차이를 만든다.");
        categoryQuotes.put("자기계발", selfDevelopment);

        // 동기부여
        List<String> motivation = new ArrayList<>();
        motivation.add("꿈을 포기하지 말고 계속 추진하라.");
        motivation.add("포기하지 않는 자만이 성공할 수 있다.");
        motivation.add("노력 없이는 아무것도 얻을 수 없다.");
        categoryQuotes.put("동기부여", motivation);

        // 관계
        List<String> relationship = new ArrayList<>();
        relationship.add("진정한 친구는 어려울 때 함께 있어주는 사람이다.");
        relationship.add("사랑은 주는 것이지 받는 것이 아니다.");
        relationship.add("이해는 용서의 시작이다.");
        categoryQuotes.put("관계", relationship);

        // 위안
        List<String> comfort = new ArrayList<>();
        comfort.add("모든 것이 괜찮아질 것이다.");
        comfort.add("지금의 고통도 지나갈 것이다.");
        comfort.add("당신은 혼자가 아니다.");
        categoryQuotes.put("위안", comfort);

        // 감사
        List<String> gratitude = new ArrayList<>();
        gratitude.add("감사하는 마음이 행복의 열쇠다.");
        gratitude.add("작은 것에도 감사할 줄 아는 사람이 행복하다.");
        gratitude.add("오늘 하루도 감사한 일이다.");
        categoryQuotes.put("감사", gratitude);
    }

    private void setupAdapters() {
        List<String> categories = new ArrayList<>(categoryQuotes.keySet());
        categoryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, categories);
        lvCategories.setAdapter(categoryAdapter);

        quoteAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        lvQuotes.setAdapter(quoteAdapter);
    }

    private void setupClickListeners() {
        lvCategories.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedCategory = (String) parent.getItemAtPosition(position);
                tvSelectedCategory.setText(selectedCategory + " 명언");

                List<String> quotes = categoryQuotes.get(selectedCategory);
                quoteAdapter.clear();
                quoteAdapter.addAll(quotes);
                quoteAdapter.notifyDataSetChanged();
            }
        });

        lvQuotes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedQuote = (String) parent.getItemAtPosition(position);
                // 북마크에 추가하는 기능은 BookmarkManager에서 구현
                DatabaseHelper dbHelper = new DatabaseHelper(CategoryActivity.this);
                dbHelper.addBookmark(selectedQuote);

                // 간단한 토스트 메시지
                android.widget.Toast.makeText(CategoryActivity.this, "북마크에 추가되었습니다.", android.widget.Toast.LENGTH_SHORT).show();
            }
        });
    }
}