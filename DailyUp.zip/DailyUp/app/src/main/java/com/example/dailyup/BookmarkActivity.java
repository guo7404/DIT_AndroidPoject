package com.example.dailyup;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class BookmarkActivity extends AppCompatActivity {

    private ListView lvBookmarks;
    private TextView tvEmptyMessage;
    private ArrayAdapter<String> bookmarkAdapter;
    private List<String> bookmarks;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmark);

        initializeViews();
        loadBookmarks();
        setupClickListeners();
    }

    private void initializeViews() {
        lvBookmarks = findViewById(R.id.lv_bookmarks);
        tvEmptyMessage = findViewById(R.id.tv_empty_message);
        dbHelper = new DatabaseHelper(this);
    }

    private void loadBookmarks() {
        bookmarks = dbHelper.getAllBookmarks();

        if (bookmarks.isEmpty()) {
            lvBookmarks.setVisibility(View.GONE);
            tvEmptyMessage.setVisibility(View.VISIBLE);
        } else {
            lvBookmarks.setVisibility(View.VISIBLE);
            tvEmptyMessage.setVisibility(View.GONE);

            bookmarkAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, bookmarks);
            lvBookmarks.setAdapter(bookmarkAdapter);
        }
    }

    private void setupClickListeners() {
        lvBookmarks.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedQuote = bookmarks.get(position);
                showDeleteDialog(selectedQuote, position);
                return true;
            }
        });
    }

    private void showDeleteDialog(final String quote, final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("북마크 삭제");
        builder.setMessage("이 명언을 북마크에서 삭제하시겠습니까?");

        builder.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dbHelper.deleteBookmark(quote);
                bookmarks.remove(position);
                bookmarkAdapter.notifyDataSetChanged();

                if (bookmarks.isEmpty()) {
                    lvBookmarks.setVisibility(View.GONE);
                    tvEmptyMessage.setVisibility(View.VISIBLE);
                }

                Toast.makeText(BookmarkActivity.this, "북마크에서 삭제되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("취소", null);
        builder.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadBookmarks(); // 화면으로 돌아올 때마다 북마크 목록 새로고침
    }
}