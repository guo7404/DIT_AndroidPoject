package com.example.dailyup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView tvTodayQuote;
    private Button btnCategories;
    private Button btnBookmarks;
    private Button btnSettings;
    private Button btnNewQuote;

    // 샘플 명언 데이터
    private String[] quotes = {
            "성공은 준비된 기회와 노력이 만나는 지점에서 일어난다.",
            "오늘 할 수 있는 일을 내일로 미루지 말라.",
            "실패는 성공의 어머니다.",
            "꿈을 포기하지 말고 계속 추진하라.",
            "작은 변화가 큰 차이를 만든다.",
            "매일 조금씩 발전하는 것이 중요하다.",
            "포기하지 않는 자만이 성공할 수 있다.",
            "노력 없이는 아무것도 얻을 수 없다."
    };

    private Random random;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupClickListeners();

        random = new Random();
        showTodayQuote();

        // 알림 채널 생성
        NotificationHelper.createNotificationChannel(this);
    }

    private void initializeViews() {
        tvTodayQuote = findViewById(R.id.tv_today_quote);
        btnCategories = findViewById(R.id.btn_categories);
        btnBookmarks = findViewById(R.id.btn_bookmarks);
        btnSettings = findViewById(R.id.btn_settings);
        btnNewQuote = findViewById(R.id.btn_new_quote);
    }

    private void setupClickListeners() {
        btnCategories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CategoryActivity.class);
                startActivity(intent);
            }
        });

        btnBookmarks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, BookmarkActivity.class);
                startActivity(intent);
            }
        });

        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        btnNewQuote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTodayQuote();
            }
        });
    }

    private void showTodayQuote() {
        int randomIndex = random.nextInt(quotes.length);
        tvTodayQuote.setText(quotes[randomIndex]);
    }
}